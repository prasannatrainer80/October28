function show(company='Hexa'){
    console.log("Company Name is " +company);
}