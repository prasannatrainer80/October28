let x = 10;
if (x== 10) {
    let x = 20;
    document.writeln("X value in Ctrl Structure  " +x);
}
document.writeln("X  alue outside If is  " +x);