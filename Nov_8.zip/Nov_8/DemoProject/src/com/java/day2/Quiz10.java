package com.java.day2;

public class Quiz10 {

	public static void main(String[] args) {
		int i=10;
		int j=i++;
		System.out.println(i + " " +j);
	}
}
