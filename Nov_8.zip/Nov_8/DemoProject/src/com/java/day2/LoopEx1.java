package com.java.day2;

public class LoopEx1 {
	public void show() {
		int i=0;
		while(i < 10) {
			System.out.println("From Hexaware...");
			i++;
		}
	}
	public static void main(String[] args) {
		LoopEx1 obj = new LoopEx1();
		obj.show();
	}
}
