package com.java.day2;

public class Quiz4 {

	public static void main(String[] args) {
		int i =8;
		while(i < 9 ) {
			System.out.println("hexaware");
			i--;
		}
		
	}
}
