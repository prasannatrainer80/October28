package com.java.day2;

public class Quiz13 {

	public static void main(String[] args) {
//		while(true) {
//			System.out.println("Hello...");
//		}
		for(;;) {
			System.out.println("Hello");
		}
	}
}
