package com.java.day2;

public class Demo {

	public void sayHello() {
		System.out.println("Welcome to Java Programming...");
	}
	
	void company() {
		System.out.println("From hexaware...");
	}
	
	private void courseName() {
		System.out.println("Segue Course Java Training...");
	}
}
