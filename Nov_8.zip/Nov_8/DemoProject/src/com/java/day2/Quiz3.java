//package com.java.day2;
//
//public class Quiz3 {
//
//	public static void main(String[] args) {
//		int i;
//		System.out.println(i);
//	}
//}
