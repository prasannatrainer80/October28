package com.java.day2;

public class Quiz11 {

	public static void main(String[] args) {
		char ch='A';
		int x = ch;
		System.out.println(x);
	}
}
