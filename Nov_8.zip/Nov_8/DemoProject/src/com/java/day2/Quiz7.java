package com.java.day2;

public class Quiz7 {

	public static void main(String[] args) {
		int i=12;
		int j = i++ + ++i;
		System.out.println(j);
	}
}
