package com.java.day2;

public class Quiz12 {

	public static void main(String[] args) {
//		int x = 3;
//		boolean flag = (x > 3 && x==3);
//		System.out.println(flag);
		int x = 3;
		boolean flag = (x > 3 || x==3);
		System.out.println(flag);
	}
}
