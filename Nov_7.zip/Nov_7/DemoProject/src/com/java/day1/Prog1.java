package com.java.day1;

public class Prog1 {

	public static void main(String[] args) {
		String name;
		int x;
		double y;
		boolean flag;
		
		name = "Trisha";
		x=12;
		y=12.5;
		flag = true;
		
		System.out.println("Name is  " +name);
		System.out.println("X value  "+x);
		System.out.println("Y value  " +y);
		System.out.println("Boolean Value  " +flag);
	}
}
