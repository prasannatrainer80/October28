package com.java.day3;

public class Quiz2 {

	public static void main(String[] args) {
		String s1="Sundhara", s2="Varsha", s3="Jayanth", s4="Sundhara";
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s3.hashCode());
		System.out.println(s4.hashCode());
	}
}
