package com.java.day3;

public class Student {

	int sid;
	String sname;
}
