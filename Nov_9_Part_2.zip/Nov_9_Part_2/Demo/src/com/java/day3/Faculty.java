package com.java.day3;

public class Faculty {

	int fid;
	String fname;
}
