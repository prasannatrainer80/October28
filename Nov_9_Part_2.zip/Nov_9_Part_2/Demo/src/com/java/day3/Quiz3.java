package com.java.day3;

public class Quiz3 {

	public static void main(String[] args) {
		String s1="Hello ";
		s1.concat(" World");
		System.out.println(s1);
	}
}
