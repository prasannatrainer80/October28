package com.java.day3;

public class Admin {

	int aid;
	String adminName;
}
