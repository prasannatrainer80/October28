package com.java.junit;

public class App {

  public static void main(String[] args) {
	  Employ employ2 = new Employ(1, "Jansu", Gender.FEMALE, "Java", 
				"Programmer", 88822);
	  System.out.println(employ2);
  }

}
