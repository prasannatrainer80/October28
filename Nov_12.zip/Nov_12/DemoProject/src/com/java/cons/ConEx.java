package com.java.cons;

public class ConEx {

	public static void main(String[] args) {
		Employ employ1 = new Employ(1, "Amega", 99234);
		Employ employ2 = new Employ(3, "Lavanya", 99211);
		System.out.println(employ1);
		System.out.println(employ2);
	}
}
