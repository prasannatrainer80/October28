package com.java.project;

public class EmployException {

}
