package com.java.ex;

public class SbExample {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();
		sb.append("Hi How are You...");
		sb.append("From Hexaware...");
		sb.append("Thank You All...");
		System.out.println(sb);
	}
}
