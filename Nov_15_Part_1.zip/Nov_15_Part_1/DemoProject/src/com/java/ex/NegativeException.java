package com.java.ex;

public class NegativeException extends Exception {

	NegativeException(String error) {
		super(error);
	}
}
