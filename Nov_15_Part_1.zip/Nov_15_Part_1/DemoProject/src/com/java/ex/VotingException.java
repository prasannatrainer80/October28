package com.java.ex;

public class VotingException extends Exception {

	VotingException(String error) {
		super(error);
	}
	
} 
