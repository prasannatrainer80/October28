package com.java.cons;

public class ConEmploy {

	public static void main(String[] args) {
		Employ e1 = new Employ(1, "Praveen", 84823.88);
		Employ e2 = new Employ(3, "Rajbharath", 99994.23);
		
		System.out.println(e1);
		System.out.println(e2);
	}
}
