package com.java.day4;

public enum OrderStatus {
	PENDING, DELIVERED, CANCELLED, ACCEPTED, REJECTED
}
