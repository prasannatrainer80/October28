package com.java.day4;

public class Quiz1 {

	boolean climate;
	public static void main(String[] args) {
//		Quiz1 obj = new Quiz1();
//		System.out.println(obj.climate);
		System.out.println(new Quiz1().climate);
		int x=12;
	    System.out.println(x++ + x++ + ++x);

	}
}
