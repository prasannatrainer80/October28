package com.java.day4;

//public class Test {
//
//	int a, b;
//	a = 5;
//	b = 7;
//}
